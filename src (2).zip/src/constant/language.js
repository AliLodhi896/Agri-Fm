import englishJson from './English.json';
import spainJson from './Spain.json';
import brazilJson from './Brazil.json';


export const english = englishJson;
export const spain = spainJson;
export const brazil = brazilJson;
