export const base_url =
  'https://socialagri.com/agriFM/wp-content/themes/agriFM/laptop';
  
  