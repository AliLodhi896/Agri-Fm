export default {
    primary:'#422C5E',
    secondary:'white',
    button:'#9EBE43',
    placeholder:'#B9B9B9',
    lightPurple:'#584571',
    lightBackground:'#E6E3EB'

};